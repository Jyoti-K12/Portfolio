// const routes = [
//     {
//         path: '/',
//         element: <Home />,
//         exact: true
//     },
//     {
//         path: '/about',
//         element: <About />,
//         exact: true
//     },
//     {
//         path: '*',
//         element: <NotFound />
//     }
// ];
